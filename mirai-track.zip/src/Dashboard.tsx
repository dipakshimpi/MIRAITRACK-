import React, { useState, useEffect } from 'react';
import { db, collection, onSnapshot, query, orderBy, limit } from './lib/firebase';
import { UserProfile, DailyReport } from './types';
import { Card, CardContent, CardHeader, CardTitle } from './components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './components/ui/table';
import { Badge } from './components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './components/ui/avatar';
import { Progress } from './components/ui/progress';
import { CheckCircle2, XCircle, TrendingUp, Users, Calendar, Clock } from 'lucide-react';
import { format } from 'date-fns';
import { motion } from 'motion/react';

export default function Dashboard() {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [recentReports, setRecentReports] = useState<DailyReport[]>([]);
  const todayStr = format(new Date(), 'yyyy-MM-dd');

  useEffect(() => {
    const unsubUsers = onSnapshot(collection(db, 'users'), (snap) => {
      setUsers(snap.docs.map(d => d.data() as UserProfile));
    });

    const unsubReports = onSnapshot(
      query(collection(db, 'reports'), orderBy('createdAt', 'desc'), limit(10)),
      (snap) => {
        setRecentReports(snap.docs.map(d => ({ id: d.id, ...d.data() } as DailyReport)));
      }
    );

    return () => {
      unsubUsers();
      unsubReports();
    };
  }, []);

  const getTodayStatus = (userId: string) => {
    const report = recentReports.find(r => r.userId === userId && r.date === todayStr);
    return report ? 'submitted' : 'pending';
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard title="Total Members" value={users.length} icon={<Users className="w-5 h-5" />} color="bg-blue-500" />
        <StatCard title="Submitted Today" value={recentReports.filter(r => r.date === todayStr).length} icon={<CheckCircle2 className="w-5 h-5" />} color="bg-green-500" />
        <StatCard title="Pending" value={users.length - recentReports.filter(r => r.date === todayStr).length} icon={<Clock className="w-5 h-5" />} color="bg-amber-500" />
        <StatCard title="Avg Productivity" value="84%" icon={<TrendingUp className="w-5 h-5" />} color="bg-indigo-500" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Employee Table */}
        <Card className="lg:col-span-2 border-none shadow-lg bg-white/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-xl font-bold flex items-center gap-2">
              <Users className="w-5 h-5 text-indigo-600" />
              Team Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent border-slate-100">
                  <TableHead className="w-[250px]">Member</TableHead>
                  <TableHead>Today</TableHead>
                  <TableHead>Score</TableHead>
                  <TableHead className="text-right">Attendance</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map((user) => (
                  <TableRow key={user.uid} className="group hover:bg-slate-50/50 transition-colors border-slate-50">
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-9 w-9 border-2 border-white shadow-sm">
                          <AvatarFallback className="bg-indigo-100 text-indigo-700 font-bold">
                            {user.name.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex flex-col">
                          <span className="text-slate-900">{user.name}</span>
                          <span className="text-xs text-slate-400">{user.email}</span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      {getTodayStatus(user.uid) === 'submitted' ? (
                        <Badge className="bg-green-100 text-green-700 hover:bg-green-100 border-none px-2 py-0.5">
                          <CheckCircle2 className="w-3 h-3 mr-1" /> Submitted
                        </Badge>
                      ) : (
                        <Badge className="bg-slate-100 text-slate-500 hover:bg-slate-100 border-none px-2 py-0.5">
                          <Clock className="w-3 h-3 mr-1" /> Pending
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Progress value={user.productivityScore || 0} className="h-1.5 w-16 bg-slate-100" />
                        <span className="text-sm font-semibold text-slate-700">{user.productivityScore || 0}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex flex-col items-end">
                        <div className="flex gap-2 text-xs font-medium">
                          <span className="text-green-600">P: {user.totalPresent || 0}</span>
                          <span className="text-red-500">A: {user.totalAbsent || 0}</span>
                        </div>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card className="border-none shadow-lg bg-white/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-xl font-bold flex items-center gap-2">
              <Calendar className="w-5 h-5 text-indigo-600" />
              Recent Reports
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {recentReports.map((report) => (
                <div key={report.id} className="relative pl-6 border-l-2 border-slate-100 pb-2 last:pb-0">
                  <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-white border-2 border-indigo-500" />
                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between items-start">
                      <span className="text-sm font-bold text-slate-900">{report.userName}</span>
                      <span className="text-[10px] text-slate-400 font-mono">{format(report.createdAt?.toDate() || new Date(), 'HH:mm')}</span>
                    </div>
                    <p className="text-xs text-slate-600 line-clamp-2 bg-slate-50 p-2 rounded-md italic">
                      "{report.tasks}"
                    </p>
                  </div>
                </div>
              ))}
              {recentReports.length === 0 && (
                <div className="text-center py-8 text-slate-400 italic text-sm">
                  No reports submitted yet today.
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function StatCard({ title, value, icon, color }: { title: string; value: string | number; icon: React.ReactNode; color: string }) {
  return (
    <Card className="border-none shadow-md overflow-hidden group hover:shadow-lg transition-all duration-300">
      <CardContent className="p-6 flex items-center gap-4">
        <div className={`p-3 rounded-xl text-white ${color} shadow-lg shadow-${color.split('-')[1]}-100 group-hover:scale-110 transition-transform`}>
          {icon}
        </div>
        <div>
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">{title}</p>
          <p className="text-2xl font-bold text-slate-900">{value}</p>
        </div>
      </CardContent>
    </Card>
  );
}
