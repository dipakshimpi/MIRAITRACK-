import React, { useState, useEffect } from 'react';
import { auth, db, doc, getDoc, setDoc, serverTimestamp, googleProvider } from './lib/firebase';
import { signInWithPopup, GoogleAuthProvider, onAuthStateChanged, signOut } from 'firebase/auth';
import { Button } from './components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card';
import { LogIn, LogOut, ShieldCheck } from 'lucide-react';
import { UserProfile } from './types';

interface AuthProps {
  onUserChange: (user: UserProfile | null) => void;
}

export default function Auth({ onUserChange }: AuthProps) {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        const userDoc = await getDoc(doc(db, 'users', user.uid));
        if (!userDoc.exists()) {
          const newProfile: UserProfile = {
            uid: user.uid,
            name: user.displayName || 'Anonymous',
            email: user.email || '',
            createdAt: serverTimestamp(),
            totalPresent: 0,
            totalAbsent: 0,
            productivityScore: 0
          };
          await setDoc(doc(db, 'users', user.uid), newProfile);
          onUserChange(newProfile);
        } else {
          onUserChange(userDoc.data() as UserProfile);
        }
      } else {
        onUserChange(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [onUserChange]);

  const handleLogin = async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const credential = GoogleAuthProvider.credentialFromResult(result);
      const token = credential?.accessToken;
      if (token) {
        localStorage.setItem('google_calendar_token', token);
      }
    } catch (error) {
      console.error("Login failed:", error);
    }
  };

  if (loading) return <div className="flex items-center justify-center h-screen">Loading...</div>;

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-slate-50 p-4">
      <Card className="w-full max-w-md border-none shadow-xl bg-white/80 backdrop-blur-md">
        <CardHeader className="text-center space-y-2">
          <div className="mx-auto bg-indigo-600 p-3 rounded-2xl w-fit mb-2 shadow-lg shadow-indigo-200">
            <ShieldCheck className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-3xl font-bold tracking-tight text-slate-900">Mirai Track</CardTitle>
          <CardDescription className="text-slate-500">
            Transparent Productivity & Attendance System
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-4 pt-4">
          <Button 
            onClick={handleLogin} 
            className="w-full h-12 text-lg font-medium bg-indigo-600 hover:bg-indigo-700 transition-all duration-300 shadow-md hover:shadow-lg"
          >
            <LogIn className="w-5 h-5 mr-2" />
            Sign in with Google
          </Button>
          <p className="text-center text-xs text-slate-400 mt-4">
            By signing in, you agree to share your productivity data with the organization.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
